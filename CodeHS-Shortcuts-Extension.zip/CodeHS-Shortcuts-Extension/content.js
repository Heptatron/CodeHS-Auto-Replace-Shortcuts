(function() {
    'use strict';

    // Shortcut persistence using chrome.storage.sync
    function loadShortcuts() {
        return new Promise((resolve) => {
            chrome.storage.sync.get(['shortcuts'], (result) => {
                resolve(result.shortcuts || []);
            });
        });
    }

    function saveShortcuts(shortcuts) {
        chrome.storage.sync.set({ shortcuts }, () => {
            console.log('Shortcuts saved!');
        });
    }

    // CSS for the inline suggestion box
    const popupStyle = `
        #shortcutList {
            position: absolute;
            background-color: #333;
            border: 1px solid #555;
            list-style-type: none;
            padding: 5px;
            z-index: 1000;
            color: #fff6cc;
            display: none;
            border-radius: 5px;
            overflow-y: auto;
            max-height: 200px;
        }
        #shortcutList li {
            padding: 3px 0;
            cursor: pointer;
        }
    `;

    const styleSheet = document.createElement('style');
    styleSheet.textContent = popupStyle;
    document.head.appendChild(styleSheet);


    let shortcutList = null;
    let shortcuts = []; // Cache shortcuts to avoid repeated loads

    function createShortcutList() {
        if (shortcutList) shortcutList.remove();
        shortcutList = document.createElement('ul');
        shortcutList.id = 'shortcutList';
        document.body.appendChild(shortcutList);
        document.addEventListener('click', (event) => {
            if (!shortcutList.contains(event.target)) {
                shortcutList.style.display = 'none';
            }
        });
    }

    function updateShortcutList(textarea, cursorPos) {
        if (!shortcutList) createShortcutList();

        if (cursorPos === 0) {
            shortcutList.style.display = 'none';
            shortcutList.innerHTML = '';
            return;
        }

        shortcutList.innerHTML = '';

        // Load shortcuts only once, cache them for speed
        if (shortcuts.length === 0) {
            loadShortcuts().then(loadedShortcuts => {
                shortcuts = loadedShortcuts;
                updateListWithShortcuts(textarea, cursorPos);
            });
        } else {
            updateListWithShortcuts(textarea, cursorPos);
        }
    }

    function updateListWithShortcuts(textarea, cursorPos) {
        const text = textarea.value;
        let prefix = "";

        for (let i = cursorPos - 1; i >= 0; i--) {
            if (!/^[a-zA-Z0-9_]/.test(text[i])) {
                prefix = text.substring(i + 1, cursorPos);
                break;
            }
        }

        if (prefix === "") {
            prefix = text.substring(0, cursorPos);
        }

        const matchingShortcuts = shortcuts.filter(shortcut => shortcut.short.startsWith(prefix));

        if (matchingShortcuts.length > 0) {
            shortcutList.style.display = 'block';
            matchingShortcuts.forEach(({ short, replacement }) => {
                const li = document.createElement('li');
                const displayReplacement = truncateString(replacement, 50);
                li.textContent = `${short}: ${displayReplacement}`;
                li.addEventListener('click', () => {
                    performReplacement(textarea, short);
                    shortcutList.style.display = 'none';
                });
                shortcutList.appendChild(li);
            });
        } else {
            shortcutList.style.display = 'none';
        }

        requestAnimationFrame(() => {
            const textareaRect = textarea.getBoundingClientRect();
            const cursorX = textareaRect.left + getEstimatedCursorX(textarea, cursorPos);
            const cursorY = textareaRect.top + textarea.scrollHeight;
            const listX = cursorX - (shortcutList.offsetWidth / 2);
            const listY = cursorY + 5;

            shortcutList.style.left = Math.max(0, listX) + 'px';
            shortcutList.style.top = listY + 'px';
        });
    }


    function truncateString(str, maxLength) {
        if (str.length > maxLength) {
            return str.substring(0, maxLength - 3) + "...";
        }
        return str;
    }

    function getEstimatedCursorX(textarea, cursorPos) {
        const textBeforeCursor = textarea.value.substring(0, cursorPos);
        const span = document.createElement('span');
        span.style.whiteSpace = 'pre';
        span.style.fontFamily = window.getComputedStyle(textarea).fontFamily;
        span.style.fontSize = window.getComputedStyle(textarea).fontSize;
        span.textContent = textBeforeCursor;
        document.body.appendChild(span);
        const width = span.offsetWidth;
        span.remove();
        return width;
    }

    function handleInput(event) {
        const textarea = document.querySelector('textarea');
        if (!textarea) return;
        updateShortcutList(textarea, textarea.selectionStart);
        performReplacement(textarea);
    }

    function performReplacement(textarea) {
        const text = textarea.value;
        const cursorPos = textarea.selectionStart;

        shortcuts.forEach(({ short, replacement, offset = 0 }) => { //Default offset is 0
            if (text.substring(cursorPos - short.length, cursorPos) === short) {
                try {
                    const newText = text.substring(0, cursorPos - short.length) + replacement + text.substring(cursorPos);
                    //Handle potential errors in offset
                    const newCursorPos = cursorPos + replacement.length - short.length - parseInt(offset, 10);  
                    textarea.value = newText;
                    textarea.selectionStart = textarea.selectionEnd = newCursorPos;
                    return; //Exit the loop after the first replacement
                } catch (error) {
                    console.error("Error during replacement:", error);
                    //Consider adding UI feedback to the user about the error
                }
            }
        });
    }

    document.addEventListener('input', handleInput);

})();