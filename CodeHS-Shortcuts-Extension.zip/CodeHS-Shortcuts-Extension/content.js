(function() {
  'use strict';

  let shortcutList = null;
  let debounceTimer = null;
  let lastKeyCode = null;

  function createShortcutList() {
    if (shortcutList) shortcutList.remove();
    shortcutList = document.createElement('ul');
    shortcutList.id = 'shortcutList';
    shortcutList.style.position = 'absolute';
    shortcutList.style.backgroundColor = '#333';
    shortcutList.style.border = '1px solid #555';
    shortcutList.style.listStyleType = 'none';
    shortcutList.style.padding = '5px';
    shortcutList.style.zIndex = 1000;
    shortcutList.style.color = '#fff6cc';
    shortcutList.style.display = 'none';
    shortcutList.style.borderRadius = '5px';
    shortcutList.style.overflowY = 'auto';
    document.body.appendChild(shortcutList);

    document.addEventListener('click', () => {
      shortcutList.style.display = 'none';
    });
  }

  function updateShortcutList(textarea, cursorPos) {
    lastKeyCode = lastKeyCode || null;
    const isArrowOrEnter = [37, 38, 39, 40, 13].includes(lastKeyCode);

    if (!shortcutList) createShortcutList();

    if (cursorPos === 0 || isArrowOrEnter) {
      shortcutList.style.display = 'none';
      shortcutList.innerHTML = ''; 
      return;
    }

    shortcutList.innerHTML = ''; 

    chrome.storage.sync.get(['shortcuts'], (result) => {
      const shortcuts = result.shortcuts || [];
      const text = textarea.value;
      let prefix = "";

      for (let i = cursorPos - 1; i >= 0; i--) {
        if (!/^[a-zA-Z0-9]$/.test(text[i])) {
          prefix = text.substring(i + 1, cursorPos);
          break;
        }
      }

      if (prefix === "") {
        prefix = text.substring(0, cursorPos);
      }

      const matchingShortcuts = shortcuts.filter(shortcut => shortcut.short.startsWith(prefix));

      if (matchingShortcuts.length > 0) {
        shortcutList.style.display = 'block';
        matchingShortcuts.forEach(({ short, replacement }) => {
          const li = document.createElement('li');
          const displayReplacement = truncateString(replacement, 50);
          li.textContent = `${short}: ${displayReplacement}`;
          shortcutList.appendChild(li);
        });
      } else {
        shortcutList.style.display = 'none';
      }

      requestAnimationFrame(() => {
        const textareaRect = textarea.getBoundingClientRect();
        const cursorX = textareaRect.left + getEstimatedCursorX(textarea, cursorPos);
        const cursorY = textareaRect.top + textarea.scrollHeight;
        const listX = cursorX - (shortcutList.offsetWidth / 2);
        const listY = cursorY + 5;

        shortcutList.style.left = listX + 'px';
        shortcutList.style.top = listY + 'px';
      });
    });
    lastKeyCode = null;
  }

  function truncateString(str, maxLength) {
    if (str.length > maxLength) {
      return str.substring(0, maxLength - 3) + "...";
    }
    return str;
  }

  function getEstimatedCursorX(textarea, cursorPos) {
    return cursorPos * textarea.offsetWidth / textarea.value.length;
  }

  function handleInput(event) {
    const textarea = document.querySelector('textarea');
    if (!textarea) return;
    updateShortcutList(textarea, textarea.selectionStart);
    performReplacement(textarea);
  }

  function performReplacement(textarea) {
    const text = textarea.value;
    const cursorPos = textarea.selectionStart;
    chrome.storage.sync.get(['shortcuts'], (result) => {
      const shortcuts = result.shortcuts || [];
      shortcuts.forEach(({ short, replacement, offset }) => {
        if (text.substring(cursorPos - short.length, cursorPos) === short) {
          const newText = text.substring(0, cursorPos - short.length) + replacement + text.substring(cursorPos);
          const newCursorPos = cursorPos + replacement.length - short.length - offset;
          textarea.value = newText;
          textarea.selectionStart = textarea.selectionEnd = newCursorPos;
        }
      });
    });
  }

  document.addEventListener('input', handleInput);
  document.addEventListener('keydown', handleInput);
  document.addEventListener('keyup', handleInput);
})();