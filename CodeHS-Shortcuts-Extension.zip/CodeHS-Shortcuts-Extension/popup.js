document.addEventListener('DOMContentLoaded', () => {
  const table = document.createElement('table');
  table.style.width = '100%';
  table.style.borderCollapse = 'collapse';

  const headerRow = table.insertRow();
  ['Shortcut', 'Replacement', 'End Offset'].forEach(headerText => {
    const th = document.createElement('th');
    th.textContent = headerText;
    th.style.border = '1px solid #555';
    th.style.padding = '8px';
    headerRow.appendChild(th);
  });

  function addRow() {
    const row = table.insertRow();
    ['', '', '0'].forEach((value, index) => { // Default offset to 0
      const cell = row.insertCell();
      const input = document.createElement('input');
      input.type = index === 2 ? 'number' : 'text'; // Number input for offset
      input.style.width = '100%';
      input.style.border = '1px solid #555';
      input.style.padding = '4px';
      input.style.background = '#444';
      input.style.color = '#eee';
      input.value = value; // Set default value for offset
      cell.appendChild(input);
      input.addEventListener('input', saveShortcuts);
    });

    const deleteCell = row.insertCell();
    const deleteButton = document.createElement('button');
    deleteButton.textContent = 'X';
    deleteButton.classList.add('delete');
    deleteButton.onclick = () => {
      table.deleteRow(row.rowIndex);
      saveShortcuts();
    };
    deleteCell.appendChild(deleteButton);
  }

  function loadShortcuts() {
    chrome.storage.sync.get(['shortcuts'], result => {
      const shortcuts = result.shortcuts || [];
      shortcuts.forEach(shortcut => addRowWithValues(shortcut.short, shortcut.replacement, shortcut.offset));
    });
  }

  function saveShortcuts() {
    const shortcuts = [];
    for (let i = 1; i < table.rows.length; i++) {
      const row = table.rows[i];
      const short = row.cells[0].querySelector('input').value;
      const replacement = row.cells[1].querySelector('input').value;
      const offset = parseInt(row.cells[2].querySelector('input').value) || 0; //Handle non-numeric input
      if (short && replacement) {
        shortcuts.push({ short, replacement, offset });
      }
    }
    chrome.storage.sync.set({ shortcuts }, () => {
      console.log('Shortcuts saved automatically!');
    });
  }

  function addRowWithValues(short, replacement, offset) {
    const row = table.insertRow();
    let cells = row.insertCell();
    cells.innerHTML = `<input type="text" value="${short}" style="width: 100%; border: 1px solid #555; padding: 4px; background-color: #444; color: #eee;">`;
    cells = row.insertCell();
    cells.innerHTML = `<input type="text" value="${replacement}" style="width: 100%; border: 1px solid #555; padding: 4px; background-color: #444; color: #eee;">`;
    cells = row.insertCell();
    cells.innerHTML = `<input type="number" value="${offset || 0}" style="width: 100%; border: 1px solid #555; padding: 4px; background-color: #444; color: #eee;">`;
    const deleteCell = row.insertCell();
    const deleteButton = document.createElement('button');
    deleteButton.textContent = 'X';
    deleteButton.classList.add('delete');
    deleteButton.onclick = () => {
      table.deleteRow(row.rowIndex);
      saveShortcuts();
    };
    deleteCell.appendChild(deleteButton);

    const shortInput = row.cells[0].querySelector('input');
    const replacementInput = row.cells[1].querySelector('input');
    const offsetInput = row.cells[2].querySelector('input');

    shortInput.addEventListener('input', saveShortcuts);
    replacementInput.addEventListener('input', saveShortcuts);
    offsetInput.addEventListener('input', saveShortcuts);
  }

  loadShortcuts();

  const addButton = document.createElement('button');
  addButton.textContent = 'Add Shortcut';
  addButton.onclick = addRow;
  document.body.appendChild(addButton);
  document.body.appendChild(table);

  window.addEventListener('beforeunload', saveShortcuts);
});